var _c_p_dictionary_8j =
[
    [ "CPDictionaryMaxDescriptionRecursion", "_c_p_dictionary_8j.html#ae6a040c214ac71849ef4ab8dc7472c0c", null ],
    [ "CPDictionaryShowNilDeprecationMessage", "_c_p_dictionary_8j.html#a0ac5bfe88a9c9a92a0846e051884feb1", null ],
    [ "isa", "_c_p_dictionary_8j.html#a7555787328047fbcad8dd0162b407daf", null ]
];