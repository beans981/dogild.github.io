var _c_g_context_canvas_8j =
[
    [ "CGBitmapGraphicsContextCreate", "_c_g_context_canvas_8j.html#a792b63f505ae560e354bdd49de62307c", null ],
    [ "CGContextDrawImage", "_c_g_context_canvas_8j.html#aa73a703617b790a33f95044f29cd3193", null ],
    [ "CGContextDrawLinearGradient", "_c_g_context_canvas_8j.html#ad5aab9a4c77342b828db694cea80e128", null ],
    [ "CGContextDrawRadialGradient", "_c_g_context_canvas_8j.html#a8b004b4c3190240f7254fb414a495e5e", null ],
    [ "eigen", "_c_g_context_canvas_8j.html#a13ab3c971ccc7a4ca3b31228d81c7516", null ],
    [ "if", "_c_g_context_canvas_8j.html#ac27658e37ef0721fc08a0898a9b83385", null ],
    [ "to_string", "_c_g_context_canvas_8j.html#a44b5b8680504ac1d5cd6e28b3f899441", null ],
    [ "CANVAS_COMPOSITE_TABLE", "_c_g_context_canvas_8j.html#aa4673b68d2bcfd587f01f738f5eb19b4", null ],
    [ "CANVAS_LINECAP_TABLE", "_c_g_context_canvas_8j.html#acef6e7cad9745277275c1a8b41b83dde", null ],
    [ "CANVAS_LINEJOIN_TABLE", "_c_g_context_canvas_8j.html#a165af8e7c37b4daa35aaf0f76542e341", null ],
    [ "else", "_c_g_context_canvas_8j.html#a0544c3fe466e421738dae463968b70ba", null ],
    [ "hasPath", "_c_g_context_canvas_8j.html#a7af4e913f0c12001833487b3f22539c8", null ],
    [ "rotate_scale", "_c_g_context_canvas_8j.html#a6be083c29e689fd501074bb4d0ffbab6", null ]
];