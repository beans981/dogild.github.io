var _c_p_collection_view_8j =
[
    [ "CPCollectionViewAllowsMultipleSelectionKey", "_c_p_collection_view_8j.html#a6f5e8f1cf64010a5c736379a9b369173", null ],
    [ "CPCollectionViewBackgroundColorsKey", "_c_p_collection_view_8j.html#ac4545fc81a9a800b0fad4771ebad798e", null ],
    [ "CPCollectionViewMaxItemSizeKey", "_c_p_collection_view_8j.html#a2a34f079aaa3baf03b3eff47e86ed820", null ],
    [ "CPCollectionViewMaxNumberOfColumnsKey", "_c_p_collection_view_8j.html#a90ebed379dea7007b1bb39ac8b093dbd", null ],
    [ "CPCollectionViewMaxNumberOfRowsKey", "_c_p_collection_view_8j.html#ae887c8873e981f2cee4645e7ee59c0fc", null ],
    [ "CPCollectionViewMinItemSizeKey", "_c_p_collection_view_8j.html#a441f38bb0b93ea62e27bd64e878b7b8c", null ],
    [ "CPCollectionViewSelectableKey", "_c_p_collection_view_8j.html#a4a21b2b086e445a2955b744347c3402a", null ],
    [ "CPCollectionViewVerticalMarginKey", "_c_p_collection_view_8j.html#a5fb05760157ca2a6150194f015684fb1", null ],
    [ "HORIZONTAL_MARGIN", "_c_p_collection_view_8j.html#a003be77c7cea09b503b8cfff73aef3b2", null ]
];