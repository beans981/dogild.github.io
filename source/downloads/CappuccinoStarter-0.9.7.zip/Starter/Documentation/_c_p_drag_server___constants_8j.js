var _c_p_drag_server___constants_8j =
[
    [ "CPDragOperationCopy", "_c_p_drag_server___constants_8j.html#a944389d52ade84dda207e764f86e0925", null ],
    [ "CPDragOperationDelete", "_c_p_drag_server___constants_8j.html#ae0f4b1313fe3036efca612af9c2b6f97", null ],
    [ "CPDragOperationEvery", "_c_p_drag_server___constants_8j.html#a2eca1e8e4b86afa0bdbc5cd639941840", null ],
    [ "CPDragOperationGeneric", "_c_p_drag_server___constants_8j.html#afee3fdd674a61c01e44702959ad7dc1b", null ],
    [ "CPDragOperationLink", "_c_p_drag_server___constants_8j.html#af3691c354cfe94bc4bf150e385a36f36", null ],
    [ "CPDragOperationMove", "_c_p_drag_server___constants_8j.html#aea93033cd818a14176498cf7923ba8e5", null ],
    [ "CPDragOperationNone", "_c_p_drag_server___constants_8j.html#a10ed549b8e0424ca530089a1cf12bbd3", null ],
    [ "CPDragOperationPrivate", "_c_p_drag_server___constants_8j.html#adc92d628f356b09262be6fef4545aaae", null ]
];