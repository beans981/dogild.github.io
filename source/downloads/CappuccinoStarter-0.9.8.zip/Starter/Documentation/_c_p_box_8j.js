var _c_p_box_8j =
[
    [ "CPBoxPrimary", "_c_p_box_8j.html#a3d6dcfff27a0d17a0de70f19fbf206c1", null ],
    [ "CPNoBorder", "_c_p_box_8j.html#ad2a5b5d6822646de26ba6b4e36866ece", null ],
    [ "CPNoTitle", "_c_p_box_8j.html#a068e6880a9169a6da486e18af25a2220", null ],
    [ "CPAboveBottom", "_c_p_box_8j.html#a310902163c83ff6ad07f78e84e636010", null ],
    [ "CPAboveTop", "_c_p_box_8j.html#abb9a7903309597e0adb47b0008a0b996", null ],
    [ "CPAtBottom", "_c_p_box_8j.html#ae514aa6b84c2d99adc6ceeba77d8fb61", null ],
    [ "CPAtTop", "_c_p_box_8j.html#a0086757c8a3c22835aa2ae78cf749ee2", null ],
    [ "CPBelowBottom", "_c_p_box_8j.html#ab4bc75da24ea8c6d2242b5db0e3b715a", null ],
    [ "CPBelowTop", "_c_p_box_8j.html#ac55de182033b9dfd11e5180a6916689b", null ],
    [ "CPBezelBorder", "_c_p_box_8j.html#ad03f11ec606cea083149874427e685ac", null ],
    [ "CPBoxBorderTypeKey", "_c_p_box_8j.html#a388a0bb99cf560e2f0f9a7cc1b294210", null ],
    [ "CPBoxCustom", "_c_p_box_8j.html#a07bbbfc38dee980753c71781e134a826", null ],
    [ "CPBoxOldStyle", "_c_p_box_8j.html#a2b767b272bde8a9314bf2448e16e1f0d", null ],
    [ "CPBoxSecondary", "_c_p_box_8j.html#a24e20891c8890c220ffc0542bca024c8", null ],
    [ "CPBoxSeparator", "_c_p_box_8j.html#af92aa5163c47418bffb5ad7605c1b481", null ],
    [ "CPBoxTitle", "_c_p_box_8j.html#aaa6a757af458a580530db418c20f780f", null ],
    [ "CPBoxTitlePosition", "_c_p_box_8j.html#a4fe045c445e3a17e76968f12e5b48f14", null ],
    [ "CPBoxTitleView", "_c_p_box_8j.html#ac48fff9c4afdff9209996b6cd126026f", null ],
    [ "CPBoxTypeKey", "_c_p_box_8j.html#a288a4eede1ab57789d67b3e7b4d365f5", null ],
    [ "CPGrooveBorder", "_c_p_box_8j.html#a1aea0360d6473f381fbc0998d887706c", null ],
    [ "CPLineBorder", "_c_p_box_8j.html#a1099036839b91176a2b76ad135678313", null ]
];